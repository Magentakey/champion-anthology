# Panduan Pengembangan

## 1. Menambah level baru

Level baru tidak perlu mengubah inti game. Alurnya: buat kelas game, daftarkan di registry.

### Langkah

1. **Buat folder** `lib/levels/<id>/` (contoh `lib/levels/maze/`).
2. **Buat kelas game** turunan `LevelGame` (lihat kerangka di bawah).
3. **Buat fungsi pabrik** `LevelGame createXGame(LevelSession session) => XGame(session);`.
4. **Daftarkan** di `lib/levels/level_registry.dart`: isi `createGame` (dan `bossImage` jika ada) pada entri level tersebut. Entri level 3 (Maze) dan 4 (Cooking) sudah ada tanpa `createGame`, cukup ditambahkan.
5. **Tambah aset** di `assets/images/<id>/` dan daftarkan foldernya di `pubspec.yaml` (folder tidak rekursif, tiap subfolder ditulis sendiri).
6. Jalankan `flutter analyze` dan `flutter test`.

Bintang tersimpan otomatis dengan kunci `stars_<id>`. Level terbuka jika level sebelumnya minimal 1 bintang. Layar jeda, hasil, penyimpanan bintang, dan tombol back sudah ditangani `GameplayScreen`.

### Kerangka

```dart
import 'package:flame/components.dart';
import '../../core/level/level_game.dart';
import '../../core/level/level_session.dart';

LevelGame createMazeGame(LevelSession session) => MazeGame(session);

class MazeGame extends LevelGame {
  MazeGame(super.session);

  @override
  List<String> get assetPaths => const ['maze/player.png']; // relatif ke assets/images/

  @override
  Future<void> onLoad() async {
    await loadAssets();
    // ... buat komponen Flame di sini
    startStep(session.step);
  }

  @override
  void startStep(int step) {
    // Siapkan tantangan untuk step 1..3 (ukuran labirin, kecepatan, dll.)
  }

  void _onStepWon() {
    session.winStep();               // pindah ke step berikutnya, atau selesai jika Step 3
    if (session.isPlaying) {
      // jeda singkat lalu lanjutkan step berikutnya
      add(TimerComponent(
        period: 1.0,
        removeOnFinish: true,
        onTick: () => startStep(session.step),
      ));
    }
  }

  void _onStepLost() => session.loseStep(); // game berhenti, bintang = step yang dimenangkan
}
```

### Aturan yang perlu diikuti

- Level **hanya** melapor `session.winStep()` dan `session.loseStep()`. Penghitungan bintang dan layar hasil diurus inti.
- Gunakan `TimerComponent` untuk jeda, karena otomatis berhenti saat game dijeda.
- Muat gambar lewat `loadAssets()` dan `assetPaths` (cache gambar khusus level, dibersihkan saat level ditutup).
- Untuk HUD Flutter di atas arena (tombol, soal, dll.), override `buildHud(BuildContext)`.
- Untuk kalimat boss di layar hasil, override `resultMessage()`.
- Efek suara: `AudioService.instance.play(Sfx.xxx)`. Tambah SFX baru di enum `Sfx` dan taruh file `.wav` di `assets/audio/`.

## 2. Menambah atau mengubah soal (Level 2, Bob)

Semua soal ada di `assets/data/genius_questions.json`. Satu soal:

```json
{ "category": "Sains", "text": "Apa lambang kimia untuk emas?", "correct": "Au", "wrong": ["Ag", "Go", "Gd"] }
```

Aturan (dicek otomatis saat game memuat dan oleh `flutter test`):

- Tepat **3 pengecoh** dan 4 pilihan yang **unik**.
- Tidak ada soal ganda di seluruh bank.
- Minimal 15 soal per step, dan tiap step minimal 3 kategori berbeda.
- Urutan jawaban diacak otomatis; jawaban benar tidak perlu di posisi tertentu.

Step 1 = Mudah (umum), Step 2 = Sedang (sains dan sejarah), Step 3 = Sulit (pengetahuan khusus).

## 3. Mengatur kesulitan (Level 2, Bob)

Ubah angka di `lib/levels/genius/genius_config.dart`:

| Pengaturan | Arti | Nilai awal (Step 1 / 2 / 3) |
|---|---|---|
| `targetCorrect` | jawaban benar untuk menang step | 3 / 4 / 5 |
| `secondsPerQuestion` | waktu per soal (detik) | 12 / 9 / 7 |
| `lives` | kesalahan yang boleh sebelum kalah | 3 / 3 / 2 |

Ubah satu hal dalam satu waktu. `lives: 1` berarti salah sekali langsung kalah.

## 4. Mengganti aset dengan versi final

Cukup **timpa file bernama sama**, tanpa mengubah kode:

| Aset | Lokasi |
|---|---|
| Ekspresi Bob (idle, shock, laugh, defeat) | `assets/images/genius/boss_*.png` |
| Arena Colosseum, gambar intro Rock, potret HUD | `assets/images/fight/*.png` |
| Karakter menu utama (pemain) | `assets/images/home/mc_home.png` |
| Panel storyboard | `assets/images/story/panel_1.png` … `panel_4.png` |
| Efek suara | `assets/audio/*.wav` |
| Ikon aplikasi | `assets/icon/app_icon.png` dan `app_icon_fg.png`, lalu `dart run flutter_launcher_icons` |

Ukuran gambar boss sebaiknya persegi (512×512). Semua gambar bisa dibuat ulang dengan `python tools/art/pixel_all.py` (butuh Pillow, numpy untuk audio, fonttools untuk font); aturan gayanya ada di [`PIXEL_ART_STYLE.md`](PIXEL_ART_STYLE.md). Jika menambah file baru atau subfolder baru, daftarkan di `pubspec.yaml`.

## 5. Mengubah teks dan dialog

- **Teks antarmuka** (tombol, judul, pesan): `lib/app/strings.dart`.
- **Dialog Bob** (ucapan awal step, reaksi benar/salah/waktu habis, kalimat hasil): `lib/levels/genius/genius_dialog.dart`.
- **Dialog intro boss**: `introDialog` di `lib/levels/level_registry.dart`.
- **Cerita**: `lib/screens/story_data.dart` (kalimat panel).

## 6. Rilis versi baru

1. Naikkan `version` di `pubspec.yaml` (mis. `1.0.1+2`).
2. `flutter analyze` dan `flutter test` harus bersih.
3. `flutter build apk --release`.
4. Commit, lalu buat Release di GitHub dan lampirkan APK (lihat bagian rilis di README atau catatan tim).

## 5. Level Fight (Level 1): pose, animasi, dan orientasi

- **Landscape**: level mengunci orientasi lewat `LevelGame.orientations` (dipulihkan ke potret saat keluar). Tombol jeda bisa dipindah lewat `pauseButtonAlignment`, dan layar hasil menyebut "Fase" lewat `stepLabel`. Level lain tidak perlu mengubah apa pun (nilai bawaan = potret).
- **Pose** ditulis di `tools/art/fight_poses.py` (satu sumber untuk gambar dan game). Setelah mengubah pose, jalankan `python tools/art/fight_poses.py` (tambah `--sheet` untuk lembar pratinjau di `/tmp/fight_poses.png`). Skrip menulis ulang `lib/levels/fight/pose_library.dart`; **jangan edit file itu manual**.
- **Klip animasi** (urutan pose dan durasi, termasuk waktu persiapan/aktif/pemulihan serangan) ada di `lib/levels/fight/pose_clips.dart`.
- **Tampilan petarung** (kepala, garis, rambut, sabuk, ikat kepala, wajah) digambar kode di `stick_renderer.dart`; warna dan proporsinya sama dengan generator art.
- **Tuning** fase, HP, kecepatan, dan sifat Rock per fase: `lib/levels/fight/fight_config.dart`. Damage, dorongan, dan lama terhenti tiap serangan: `attacks.dart` (jendela waktu hantam otomatis mengikuti klip animasinya). Kalimat Rock: `fight_dialog.dart`.
- **Arsitektur tempur**: `fighter_body.dart` (satu petarung: HP, mesin keadaan, serangan, tangkis, animasi) dan `fight_arena.dart` (dua petarung, pisau, penyelesaian hit) adalah Dart murni tanpa Flame sehingga bisa di-unit-test (`test/levels/fight/combat_test.dart`). `fight_game.dart` menghubungkannya ke Flame, HUD, dan sesi core.
- **Alur fase**: Rock hanya punya satu bar HP; saat HP-nya menyentuh batas fase (67% dan 33%), `FightGame` memanggil `session.winStep()` lalu `startStep(next)` tanpa memutus pertarungan. KO Rock di fase 3 memanggil `winStep()` terakhir; KO pemain memanggil `loseStep()`.
- **Kontrol di desktop** (untuk uji cepat di Windows): panah atau A/D untuk gerak, J pukul, K tendang, L atau S tangkis, I pisau.
- **Panel uji**: tombol `DEV` di bawah layar (hanya muncul di build debug, yaitu `flutter run`; tidak ada di APK rilis) membuka panel untuk memutar animasi, mengatur Rock diam atau menyerang, dan memaksa menang fase atau kalah.
- **Kunci level**: level terbuka jika level sebelumnya punya minimal 1 bintang, atau level itu sendiri sudah punya bintang (progres lama tidak terkunci ulang saat urutan level berubah).
- **Audio**: suara pertarungan dan musik latar dibuat oleh `tools/audio/generate_fight_audio.py` (`pip install numpy`, lalu `python tools/audio/generate_fight_audio.py`), ditulis ke `assets/audio/`. Ganti suara dengan menimpa file bernama sama. Daftar suara ada di enum `Sfx` (`audio_service.dart`); musik latar `fight_bgm.wav` diputar `AudioService.playBgm` dan ikut tombol mute di menu jeda.
- **Efek**: slow-motion saat KO, teks "K.O.!", kilat merah saat pemain terkena, penonton melonjak saat ramai, obor menyala di fase 3 (`arena_component.dart`), dan getar haptic (`fight_game.dart`).
- **Petunjuk di layar intro** diatur lewat `LevelDefinition.tip`.
- **Combo dan serangan tenaga pemain** (`combosEnabled` di `FighterBody`, hanya pemain): pukul, silang, uppercut; pukul, silang, tendang putar (`comboKick`); tendang, tendang tinggi (`kickHigh`); tahan pukul lalu lepas = `chargeSlam` atau `chargeFull` (ambang waktu `chargeTapMs`, `chargeMinMs`, `chargeFullMs` di `fight_config.dart`; logika ketuk atau tahan di `punch_input.dart`). Rasa tiap pukulan (hit-stop, getar, suara, gerak lambat, debu) ada di `hit_feel.dart`. Klip baru sengaja memakai waktu klip lama agar angka tuning tidak bergeser.
- **AI Rock** ada di `enemy_ai.dart` (Dart murni, bisa di-test dengan `Random` ber-seed). Angka per fase (kecepatan, jeda reaksi, jeda serang, damage, peluang menangkis, membalas, menghukum) ada di `rockPhaseStats` pada `fight_config.dart`. Susunan combo dan pilihan serangan khusus tiap fase ada di `_choosePlan`. Serangan khusus (`Attacks.roundhouse`, `heavy`, `dash`) didefinisikan di `attacks.dart` dengan aba-aba (`telegraphMs`), terjang (`lunge`), armor, dan faktor tembus saat ditangkis (`blockedFactor`).


## Mengatur kesulitan Level 3 (labirin)

Semua angka ada di `lib/levels/maze/maze_config.dart`:

- `mazeSteps`: ukuran (`cols` x `rows`) dan batas waktu (`seconds`) tiap step. Menambah ukuran memperpanjang jalur; sesuaikan waktunya.
- `MazeTuning.repeatSeconds`: jeda antar langkah saat tombol ditahan (kecil = pemain lebih cepat).
- `MazeLayout`: posisi labirin, bar waktu, dan tombol arah. Ubah di sini saja; Flame dan HUD sama-sama membacanya.
- Kalimat Asep ada di `maze_dialog.dart`.

Tes `maze_grid_test.dart` memastikan jalur terpanjang tiap step bisa ditempuh dalam kurang dari setengah batas waktu; jalankan `flutter test` setelah mengubah angka.


## Mengatur kesulitan dan isi Level 4 (memasak)

Semua angka ada di `lib/levels/cooking/cooking_config.dart`:

- `cookingSteps`: jumlah bahan, pengecoh, batas waktu, dan parameter tiap cooking check (`ChopParams`, `BoilParams`, `FryParams`).
- `CookingTuning`: penalti salah stasiun (3 dtk), penalti check gagal (4 dtk), bonus check mulus (1 dtk).
- `CookingLayout`: posisi kartu pesanan, stasiun, baki. Flame dan HUD sama-sama membacanya.

**Menambah resep atau bahan** (`cooking_models.dart`):

1. Bahan baru: tambah satu entri di `ingredientCatalog` (id, nama, stasiun), lalu tambahkan fungsi `ing_<id>()` dan daftarnya di `INGREDIENTS` pada `tools/art/pixel_cooking.py`, jalankan skripnya. Tes memeriksa semua gambar ada.
2. Resep baru: tambah `Recipe(nama, [id bahan...])` di `recipes`. Minimal 5 bahan, dan 3 bahan pertama harus mencakup minimal 2 stasiun (step 1 memakai 3 bahan pertama).

Cooking check berupa kelas Dart murni di `cooking_checks.dart` (tanpa Flame/Flutter), jadi mudah diuji dan ikut berhenti saat jeda. Stasiun baru = enum `Station` + kelas `CookingCheck` baru + satu panel di `cooking_hud.dart`.


## Mengatur kesulitan Level 5 (panahan)

Semua angka ada di `lib/levels/archery/archery_config.dart`:

- `archerySteps`: jumlah anak panah, skor target, simpangan dan kecepatan goyangan bidikan (`aimX`, `aimY`, `aimSpeed`), pertambahan gemetar per detik setelah busur penuh (`shake`), kekuatan angin (`wind`), dan gerak papan (`targetX`, `targetY`, `targetSpeed`). Satuan jarak 1,0 = jari-jari papan.
- `ArcheryTuning`: lama tarikan penuh (`fillSeconds`), kekuatan minimum (`minPower`), batas waktu tembakan (`shotSeconds`), dan skor tiap cincin.
- `ArcheryLayout`: posisi papan, penunjuk angin, dan panel kontrol (Flame dan HUD membaca angka yang sama).
- Kalimat Bima ada di `archery_dialog.dart`.

`archery_test.dart` memainkan bot melawan konfigurasi: pemain sempurna harus menang hampir selalu, yang ceroboh, terlalu cepat, atau acak hampir tidak boleh menang. Jalankan `flutter test` setelah mengubah angka; kalau tes gagal berarti kesulitan bergeser terlalu jauh.


## Mengatur Level 6 (gambler)

Semua angka ada di `lib/levels/gambler/gambler_config.dart`:

- `gamblerWinChance`: peluang menang tiap step (0,75, 0,5, 0,25). **Ini konstanta tetap**: tidak ada bonus setelah kalah dan tidak ada penyesuaian diam-diam. Label di layar (`GamblerDialog.oddsLabel`) membaca angka yang sama. Tes `gambler_test.dart` memastikan ketiga angka itu satu-satunya angka pecahan di berkas konfigurasi dan cocok dengan jumlah kartu, sisi, dan cangkir.
- `GamblerTuning`: jumlah kartu (`cardCount`, `bombCount`), cangkir (`cupCount`), jumlah tukar acakan (`shuffleSwaps`), dan durasi semua animasi dalam milidetik. Mengubah jumlah kartu atau cangkir otomatis mengubah peluang sebenarnya, jadi sesuaikan juga `gamblerWinChance`; tes akan gagal kalau keduanya tidak cocok.
- `GamblerLayout` (di `gambler_table.dart`): posisi meja, label peluang, dan panel kontrol. Flame dan HUD membaca angka yang sama.
- Kalimat Mr. Lexi ada di `gambler_dialog.dart`. Font piksel hanya punya huruf besar, angka, dan tanda baca dasar; tes memeriksa karakter yang dipakai.

Cara kerja keadilan: `GamblerRun.beginStep` menempatkan hasil (kartu sial, sisi koin yang mendarat, atau cangkir berbola) sebelum pemain memilih, memakai `Random` yang diberikan dari luar. Pilihan pemain hanya dibandingkan dengan penempatan itu. Animasi (balik kartu, lempar koin, acakan cangkir) tidak pernah menentukan hasil; acakan cangkir direncanakan mundur dari susunan akhir (`CupShuffle`).

Aset dibuat oleh `tools/art/pixel_gambler.py` (latar, kartu, koin, cangkir, bola, chip), boss oleh `pixel_bosses.py`, dan suara oleh `tools/audio/generate_gambler_audio.py`.

## Mengatur Level 7 (rhythm)

Semua angka ada di `lib/levels/rhythm/rhythm_config.dart`:

- `rhythmBpm`, `rhythmBars`, `rhythmNoteCount`, `rhythmDoubleCount`, dan `rhythmPassThreshold` (0,6, 0,7, 0,78): tabel tiap step. `rhythmSeeds` menentukan lagu; seed yang sama selalu menghasilkan lagu yang sama.
- `RhythmTuning`: jendela penilaian (`perfectWindowMs` 50, `goodWindowMs` 110, `missWindowMs` 130), waktu jatuh (`fallMs` 1400), hitung mundur, dan rentang offset (-150 sampai +150, langkah 10).
- Aturan pembuat lagu ada di `ChartRules` (`rhythm_chart.dart`); `RhythmChart.forStep` memberi kisi dan batas lompat jalur tiap step. Mengubah seed atau aturan tidak memerlukan perubahan lain, tes aturan lagu akan memeriksa hasilnya.
- Tata letak panggung, pad, dan bar semangat: `RhythmLayout` di `rhythm_stage.dart` (Flame dan HUD membaca angka yang sama).
- Kalimat Rhea di `rhythm_dialog.dart`; font piksel hanya punya huruf besar, angka, dan tanda baca dasar, dan tes memeriksa karakternya.

Cara kerja: `RhythmRun` adalah mesin tahap murni (banner, hitung mundur 4 ketukan, bermain, hasil, jeda antar step) yang melapor ke `LevelSession` tepat sekali per step. Penilaian memakai jam permainan di `RhythmRun`, bukan posisi pemutar audio, sehingga tidak bergantung pada keterlambatan audio; lagu dimulai bersamaan dengan jam 0 dan offset menggeser jadwal not. Uji di HP sungguhan: bila ketukan terasa terlalu cepat atau lambat terhadap suara, geser offset di layar jeda.

Aset dibuat oleh `tools/art/pixel_rhythm.py` (panggung, not, pad, garis ketuk), boss oleh `pixel_bosses.py`, dan lagu serta suara oleh `tools/audio/generate_rhythm_audio.py` (numpy; durasi lagu persis sama dengan panjang bar, dicek tes).

## Mengatur Level 8 (memory)

Semua angka ada di `lib/levels/memory/memory_config.dart`:

- Tabel per step: `memoryPadCount` (4, 6, 9), `memoryStartLength` (3, 4, 5), `memoryRounds` (5, 6, 7), `memoryShowMs` (600, 500, 420), `memoryLives` (3, 2, 2), `memoryInputTimeoutMs` (5000, 4000, 3000), dan `memoryGridColumns`/`memoryGridRows`. Panjang urutan ronde r = `memoryStartLength + r - 1`.
- `MemoryTuning`: porsi menyala (`litFraction` 0,7) dan semua jeda (intro, antar ronde, ulang, hasil, kilatan salah).
- Aturan urutan ada di `MemorySequence` (`memory_sequence.dart`): tanpa tiga simbol sama berturut-turut (`memoryMaxRepeat`) dan semua pad muncul pada urutan ronde terakhir. `Random` disuntikkan sehingga tes bisa memakai urutan tetap.
- Tata letak, warna, bentuk, dan nada pad: `MemoryLayout` dan daftar `memoryPad*` di `memory_stage.dart` (Flame dan HUD membaca angka yang sama; pad minimal 56 dp).
- Kalimat Mira di `memory_dialog.dart`; font piksel hanya punya huruf besar, angka, dan tanda baca dasar, dan tes memeriksa karakternya.

Cara kerja: `MemoryRound` adalah mesin tahap murni (banner, tonton, ketuk, ronde selesai, ulang, hasil, jeda antar step) yang melapor ke `LevelSession` tepat sekali per step. Satu ketukan diproses per frame. Jika level terasa terlalu sulit atau mudah, ubah `memoryLives[2]` atau `memoryRounds[2]` lebih dulu; tes simulasi menunjukkan dampaknya pada peluang lulus.

Aset dibuat oleh `tools/art/pixel_memory.py` (panggung, 9 pad, ikon nyawa), boss oleh `pixel_bosses.py`, dan nada serta efek suara oleh `tools/audio/generate_memory_audio.py` (numpy).
