import 'package:champion_anthology/core/save/progress_repository.dart';
import 'package:champion_anthology/levels/level_registry.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<(ProviderContainer, SharedPreferences)> makeContainer([
  Map<String, Object> initial = const {},
]) async {
  SharedPreferences.setMockInitialValues(initial);
  final prefs = await SharedPreferences.getInstance();
  final container = ProviderContainer(
    overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
  );
  addTearDown(container.dispose);
  return (container, prefs);
}

void main() {
  test('bintang hanya naik, tidak pernah turun, dan tersimpan', () async {
    final (container, prefs) = await makeContainer();
    final notifier = container.read(progressProvider.notifier);

    await notifier.submitStars('genius', 2);
    await notifier.submitStars('genius', 1); // hasil lebih buruk: diabaikan

    expect(container.read(progressProvider)['genius'], 2);
    expect(prefs.getInt('stars_genius'), 2);
  });

  test('bintang dibatasi 0..3', () async {
    final (container, _) = await makeContainer();
    await container.read(progressProvider.notifier).submitStars('genius', 9);
    expect(container.read(progressProvider)['genius'], 3);
  });

  test('progres dimuat dari penyimpanan saat aplikasi dibuka', () async {
    final (container, _) = await makeContainer({'stars_genius': 3});
    expect(container.read(progressProvider)['genius'], 3);
    expect(container.read(progressProvider)['maze'], 0);
  });

  test('Fight (level 1) selalu terbuka; Bob terbuka setelah Fight punya bintang', () async {
    final (container, _) = await makeContainer({'stars_fight': 1});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('fight')!), isTrue);
    expect(notifier.isUnlocked(levelById('genius')!), isTrue);
    expect(notifier.isUnlocked(levelById('maze')!), isFalse); // Bob belum punya bintang
  });

  test('Asep (level 3) terbuka setelah Bob punya bintang; Cooking menunggu Asep', () async {
    final (container, _) = await makeContainer({'stars_fight': 1, 'stars_genius': 1});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('maze')!), isTrue);
    expect(notifier.isUnlocked(levelById('cooking')!), isFalse);
  });

  test('Cooking Champion (level 4) terbuka setelah Asep punya bintang', () async {
    final (container, _) = await makeContainer({'stars_maze': 1});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('cooking')!), isTrue);
  });

  test('Bima (level 5) terbuka setelah Cooking Champion punya bintang', () async {
    final (container, _) = await makeContainer({'stars_cooking': 1});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('archery')!), isTrue);
    expect(levelById('archery')!.number, 5);
  });

  test('Bima terkunci selama Cooking Champion belum punya bintang', () async {
    final (container, _) = await makeContainer({'stars_maze': 3});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('archery')!), isFalse);
  });

  test('Mr. Lexi (level 6) terbuka setelah Bima punya bintang', () async {
    final (container, _) = await makeContainer({'stars_archery': 1});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('gambler')!), isTrue);
    expect(levelById('gambler')!.number, 6);
  });

  test('Mr. Lexi terkunci selama Bima belum punya bintang', () async {
    final (container, _) = await makeContainer({'stars_cooking': 3});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('gambler')!), isFalse);
  });

  test('Rhea (level 7) terbuka setelah Mr. Lexi punya bintang', () async {
    final (container, _) = await makeContainer({'stars_gambler': 1});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('rhythm')!), isTrue);
    expect(levelById('rhythm')!.number, 7);
  });

  test('Rhea terkunci selama Mr. Lexi belum punya bintang', () async {
    final (container, _) = await makeContainer({'stars_archery': 3});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('rhythm')!), isFalse);
  });

  test('Mira (level 8) terbuka setelah Rhea punya bintang', () async {
    final (container, _) = await makeContainer({'stars_rhythm': 1});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('memory')!), isTrue);
    expect(levelById('memory')!.number, 8);
  });

  test('Mira terkunci selama Rhea belum punya bintang', () async {
    final (container, _) = await makeContainer({'stars_gambler': 3});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('memory')!), isFalse);
  });

  test('level yang sudah punya bintang tetap terbuka walau level sebelumnya belum', () async {
    final (container, _) = await makeContainer({'stars_genius': 2});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('genius')!), isTrue);
  });

  test('Bob terkunci selama Fight belum punya bintang', () async {
    final (container, _) = await makeContainer({});
    final notifier = container.read(progressProvider.notifier);

    expect(notifier.isUnlocked(levelById('fight')!), isTrue);
    expect(notifier.isUnlocked(levelById('genius')!), isFalse);
  });
}
