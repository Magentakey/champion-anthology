import '../core/level/level_definition.dart';
import 'archery/archery_dialog.dart';
import 'archery/archery_game.dart';
import 'cooking/cooking_dialog.dart';
import 'cooking/cooking_game.dart';
import 'fight/fight_dialog.dart';
import 'fight/fight_game.dart';
import 'gambler/gambler_dialog.dart';
import 'gambler/gambler_game.dart';
import 'genius/genius_game.dart';
import 'maze/maze_dialog.dart';
import 'maze/maze_game.dart';
import 'memory/memory_dialog.dart';
import 'memory/memory_game.dart';
import 'rhythm/rhythm_dialog.dart';
import 'rhythm/rhythm_game.dart';

/// Menambah level baru = tambah satu entry di sini + satu folder di lib/levels/.
const levelRegistry = <LevelDefinition>[
  LevelDefinition(
    id: 'fight',
    number: 1,
    bossName: 'Rock the Fighter',
    introDialog: FightDialog.intro,
    tip: FightDialog.tip,
    bossImage: 'assets/images/fight/boss_idle.png',
    createGame: createFightGame,
  ),
  LevelDefinition(
    id: 'genius',
    number: 2,
    bossName: 'Bob the Genius',
    introDialog: 'Siapa kau?\nBerani menantangku?!\nTahu tempatmu!',
    bossImage: 'assets/images/genius/boss_idle.png',
    createGame: createGeniusGame,
  ),
  LevelDefinition(
    id: 'maze',
    number: 3,
    bossName: 'Asep the Mazelogist',
    introDialog: 'Selamat datang...\nIngin merebut gelarku?\nIkuti aku...',
    tip: MazeDialog.tip,
    bossImage: 'assets/images/maze/boss_idle.png',
    createGame: createMazeGame,
  ),
  LevelDefinition(
    id: 'cooking',
    number: 4,
    bossName: 'Cooking Champion',
    introDialog: CookingDialog.intro,
    tip: CookingDialog.tip,
    bossImage: 'assets/images/cooking/boss_idle.png',
    createGame: createCookingGame,
  ),
  LevelDefinition(
    id: 'archery',
    number: 5,
    bossName: 'Bima the Shooter',
    introDialog: ArcheryDialog.intro,
    tip: ArcheryDialog.tip,
    bossImage: 'assets/images/archery/boss_idle.png',
    createGame: createArcheryGame,
  ),
  LevelDefinition(
    id: 'gambler',
    number: 6,
    bossName: 'Mr. Lexi the Gambler',
    introDialog: GamblerDialog.intro,
    tip: GamblerDialog.tip,
    bossImage: 'assets/images/gambler/boss_idle.png',
    createGame: createGamblerGame,
  ),
  LevelDefinition(
    id: 'rhythm',
    number: 7,
    bossName: 'Rhea the Drummer',
    introDialog: RhythmDialog.intro,
    tip: RhythmDialog.tip,
    bossImage: 'assets/images/rhythm/boss_idle.png',
    createGame: createRhythmGame,
  ),
  LevelDefinition(
    id: 'memory',
    number: 8,
    bossName: 'Mira the Memory Keeper',
    introDialog: MemoryDialog.intro,
    tip: MemoryDialog.tip,
    bossImage: 'assets/images/memory/boss_idle.png',
    createGame: createMemoryGame,
  ),
];

LevelDefinition? levelById(String id) {
  for (final level in levelRegistry) {
    if (level.id == id) return level;
  }
  return null;
}
