import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';

import 'package:flame/components.dart';
import 'package:flame/input.dart' show KeyboardEvents;
import 'package:flutter/foundation.dart' show ValueNotifier;
import 'package:flutter/material.dart'
    show Alignment, BuildContext, KeyEventResult, Widget;
import 'package:flutter/services.dart'
    show DeviceOrientation, HapticFeedback, KeyDownEvent, KeyEvent, KeyUpEvent, LogicalKeyboardKey;

import '../../core/audio/audio_service.dart';
import '../../core/level/level_game.dart';
import '../../core/level/level_session.dart';
import 'arena_component.dart';
import 'attacks.dart';
import 'effects.dart';
import 'enemy_ai.dart';
import 'fight_arena.dart';
import 'fight_config.dart';
import 'fight_dialog.dart';
import 'fight_hud.dart';
import 'fighter.dart';
import 'hit_feel.dart';
import 'pose_clips.dart';
import 'punch_input.dart';

LevelGame createFightGame(LevelSession session) => FightGame(session);

/// Level 1: Rock the Fighter - satu lawan, tiga fase menurut batas HP.
///
/// Tahap M2-M3: gerak, pukul/tendang/tangkis/pisau, deteksi hit, HP, alur fase ke core, dan AI Rock.
/// Lawan: [EnemyAi] (M3).
class FightGame extends LevelGame with KeyboardEvents {
  FightGame(super.session);

  late final FightArena arena;
  late final ArenaComponent _bg;
  late final Fighter _playerView;
  late final Fighter _rockView;
  late final KnifeLayer _knives;
  final EnemyAi _brain = EnemyAi();
  final math.Random _rnd = math.Random();

  bool _ready = false;
  bool _transitioning = false;
  bool _resultPending = false;
  double _hitStopMs = 0;
  double _slowMoMs = 0;
  double _slowScale = 1;
  double _cheer = 0;
  bool _telegraphWas = false;
  int _knivesWas = 0;
  double _shake = 0;

  // tombol pukul: ketuk = pukulan biasa (dijalankan saat dilepas), tahan = isi serangan tenaga
  final PunchInput _punch = PunchInput();
  bool _chargeFullWas = false;
  double _unit = 1;
  double _groundY = 0;

  bool _left = false;
  bool _right = false;
  bool _block = false;

  /// Nilai untuk HUD (pecahan 0..1).
  final ValueNotifier<int> phase = ValueNotifier(1);
  final ValueNotifier<String?> banner = ValueNotifier(null);
  final ValueNotifier<double> playerHp = ValueNotifier(1);
  final ValueNotifier<double> rockHp = ValueNotifier(1);

  /// Kesiapan pisau: 1 = siap, <1 = sedang jeda.
  final ValueNotifier<double> knifeReady = ValueNotifier(1);

  /// Teks besar di tengah layar (mis. "K.O.!") dan penanda pukulan ke pemain (untuk kilat merah).
  final ValueNotifier<String?> callout = ValueNotifier(null);
  final ValueNotifier<int> hurtFlash = ValueNotifier(0);

  /// Hitungan combo pemain untuk HUD (x2, x3, ...); 0 saat tidak ada combo.
  final ValueNotifier<int> combo = ValueNotifier(0);

  /// Isi serangan tenaga 0..1 untuk HUD; 0 saat tidak mengisi.
  final ValueNotifier<double> charge = ValueNotifier(0);

  /// Mode uji: Rock menyerang atau diam.
  final ValueNotifier<bool> rockAttacks = ValueNotifier(true);

  @override
  List<String> get assetPaths => const [
        'fight/arena.png',
        'fight/player_sheet.png',
        'fight/rock_sheet.png',
      ];

  @override
  List<DeviceOrientation>? get orientations => const [
        DeviceOrientation.landscapeLeft,
        DeviceOrientation.landscapeRight,
      ];

  // Tombol jeda di tengah atas, supaya HUD kiri-kanan tidak tertutup.
  @override
  Alignment get pauseButtonAlignment => Alignment.topCenter;

  @override
  String get stepLabel => 'Fase';

  @override
  Color backgroundColor() => const Color(0xFF2B1A10);

  @override
  Widget buildHud(BuildContext context) => FightHud(game: this);

  @override
  String? resultMessage() => FightDialog.resultLine(session.stars);

  @override
  Future<void> onLoad() async {
    await loadAssets();
    arena = FightArena(worldWidth: 1);
    _bg = ArenaComponent(levelImages.fromCache('fight/arena.png'))..priority = -10;
    _rockView = Fighter(
      body: arena.rock,
      sheet: levelImages.fromCache('fight/rock_sheet.png'),
      spriteScale: 1.12, // Rock lebih besar dari pemain
    )..priority = 0;
    _playerView = Fighter(
      body: arena.player,
      sheet: levelImages.fromCache('fight/player_sheet.png'),
    )..priority = 1;
    _knives = KnifeLayer(arena)..priority = 2;
    await addAll([_bg, _rockView, _playerView, _knives]);
    _ready = true;
    _layout(size);
    startStep(session.step);
    unawaited(AudioService.instance.playBgm(AudioService.fightBgm, owner: this));
  }

  @override
  void disposeAssets() {
    AudioService.instance.stopBgm(owner: this);
    super.disposeAssets();
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    if (_ready) _layout(size);
  }

  void _layout(Vector2 s) {
    _bg.size = s;
    _unit = (s.y * ArenaLayout.fighterHeight) / ArenaLayout.figureUnits;
    _groundY = s.y * ArenaLayout.groundY;

    // jaga posisi relatif petarung saat ukuran layar berubah (mis. rotasi ke landscape)
    final oldW = arena.worldWidth;
    final pf = arena.player.x / oldW;
    final rf = arena.rock.x / oldW;
    arena.worldWidth = s.x / _unit;
    arena.player.x = pf * arena.worldWidth;
    arena.rock.x = rf * arena.worldWidth;

    for (final f in [_playerView, _rockView]) {
      f
        ..unit = _unit
        ..groundY = _groundY;
    }
    _knives
      ..unit = _unit
      ..groundY = _groundY;
  }

  // ---------------- alur fase ----------------
  @override
  void startStep(int step) {
    phase.value = step;
    _bg.setPhase(step);
    if (!_ready) return;
    arena.setStep(step);
    _showBanner('FASE $step: ${fightPhases[step - 1].name}\n${FightDialog.phaseLines[step - 1]}');
    AudioService.instance.play(Sfx.bell);
  }

  void _showBanner(String text) {
    banner.value = text;
    _later(2.2, () {
      if (banner.value == text) banner.value = null;
    });
  }

  void _showCallout(String text, double seconds) {
    callout.value = text;
    _later(seconds, () {
      if (callout.value == text) callout.value = null;
    });
  }

  void _later(double seconds, void Function() action) {
    add(TimerComponent(period: seconds, removeOnFinish: true, onTick: action));
  }

  /// Dipanggil tiap frame setelah hit diproses: KO Rock, KO pemain, atau pergantian fase.
  void _checkProgress() {
    if (_resultPending) return;
    final rock = arena.rock;
    final player = arena.player;

    if (rock.isDead) {
      _resultPending = true;
      arena.clearKnives();
      player.celebrate();
      _knockOutEffects(slowScale: 0.3, slowMs: 1000);
      _later(1.4, () {
        if (!session.isPlaying) return;
        session.winStep();
        AudioService.instance.play(Sfx.win);
      });
      return;
    }
    if (player.isDead) {
      _resultPending = true;
      arena.clearKnives();
      _knockOutEffects(slowScale: 0.4, slowMs: 700);
      _later(1.0, () {
        if (!session.isPlaying) return;
        session.loseStep();
        AudioService.instance.play(Sfx.lose);
      });
      return;
    }
    if (!_transitioning && arena.step < 3 && rock.atFloor) _beginPhaseBreak();
  }

  void _knockOutEffects({required double slowScale, required int slowMs}) {
    _slowScale = slowScale;
    _slowMoMs = slowMs.toDouble();
    _cheer = 1;
    _showCallout('K.O.!', 1.6);
    AudioService.instance.play(Sfx.ko);
    AudioService.instance.play(Sfx.crowd);
    HapticFeedback.heavyImpact();
  }

  /// Rock mencapai batas HP fase: fase dimenangkan, Rock mengamuk sebentar (kebal).
  void _beginPhaseBreak() {
    _transitioning = true;
    arena.clearKnives();
    _cheer = 1;
    AudioService.instance.play(Sfx.stepUp);
    AudioService.instance.play(Sfx.crowd);
    HapticFeedback.heavyImpact();
    arena.rock
      ..invulnerable = true
      ..playScripted(Clips.taunt, holdMs: 1500);
    final next = session.step + 1;
    session.winStep();
    if (session.isPlaying) startStep(next);
    _later(1.5, () {
      arena.rock.invulnerable = false;
      _transitioning = false;
    });
  }

  // ---------------- input pemain ----------------
  bool get _canInput => _ready && session.isPlaying && !_resultPending && !arena.player.isDead;

  /// Menjeda permainan: tombol yang sedang ditahan dilepas agar tidak "menyangkut" saat lanjut.
  @override
  void pauseEngine() {
    _left = false;
    _right = false;
    _block = false;
    _punch.reset();
    arena.player.cancelCharge();
    AudioService.instance.pauseBgm(owner: this);
    super.pauseEngine();
  }

  @override
  void resumeEngine() {
    AudioService.instance.resumeBgm(owner: this);
    super.resumeEngine();
  }

  void setMoveLeft(bool v) => _left = v;
  void setMoveRight(bool v) => _right = v;
  void setBlock(bool v) => _block = v;

  void pressPunch() {
    if (_canInput) arena.player.queuePunch();
  }

  /// Tombol pukul ditekan. Ketukan singkat menjadi pukulan saat dilepas; ditahan lebih dari
  /// [chargeTapMs] mulai mengisi serangan tenaga.
  void pressPunchDown() {
    if (_canInput) _punch.down();
  }

  void pressPunchUp() {
    switch (_punch.up()) {
      case PunchRelease.tap:
        pressPunch();
      case PunchRelease.release:
        if (arena.player.releaseCharge() != null) AudioService.instance.play(Sfx.whoosh);
      case PunchRelease.none:
        break;
    }
  }

  void _updatePunchHold(double ms) {
    if (!_punch.held) return;
    if (!_canInput) {
      _punch.reset();
      arena.player.cancelCharge();
      return;
    }
    if (_punch.update(ms) && arena.player.beginCharge()) _punch.markCharging();
    // terkena saat mengisi: isi hilang dan tombol yang masih ditahan tidak mengisi ulang
    if (_punch.charged && !arena.player.charging) _punch.chargeLost();
  }

  void pressKick() {
    if (_canInput) arena.player.queueAttack(Attacks.kick);
  }

  void pressKnife() {
    if (_canInput) arena.player.queueKnife();
  }

  @override
  KeyEventResult onKeyEvent(KeyEvent event, Set<LogicalKeyboardKey> keysPressed) {
    bool held(List<LogicalKeyboardKey> keys) => keys.any(keysPressed.contains);
    setMoveLeft(held([LogicalKeyboardKey.arrowLeft, LogicalKeyboardKey.keyA]));
    setMoveRight(held([LogicalKeyboardKey.arrowRight, LogicalKeyboardKey.keyD]));
    setBlock(held([LogicalKeyboardKey.keyL, LogicalKeyboardKey.keyS]));
    if (event is KeyDownEvent) {
      if (event.logicalKey == LogicalKeyboardKey.keyJ) pressPunchDown();
      if (event.logicalKey == LogicalKeyboardKey.keyK) pressKick();
      if (event.logicalKey == LogicalKeyboardKey.keyI) pressKnife();
    } else if (event is KeyUpEvent && event.logicalKey == LogicalKeyboardKey.keyJ) {
      pressPunchUp();
    }
    return KeyEventResult.handled;
  }

  // ---------------- siklus frame ----------------
  @override
  void update(double dt) {
    if (!_ready) {
      super.update(dt);
      return;
    }
    final real = math.min(dt, 0.05);
    _updatePunchHold(real * 1000);
    var timeScale = 1.0;
    if (_slowMoMs > 0) {
      _slowMoMs -= real * 1000; // slow-motion berjalan menurut waktu nyata
      timeScale = _slowScale;
    }
    if (_hitStopMs > 0) {
      _hitStopMs -= real * 1000;
    } else {
      _stepWorld(real * timeScale * 1000);
    }
    _shake = math.max(0, _shake - 70 * real);
    _cheer = math.max(0, _cheer - 0.8 * real);
    _bg.cheer = _cheer;
    super.update(dt * timeScale);
  }

  void _stepWorld(double dtMs) {
    final player = arena.player;
    if (_canInput) {
      player.moveInput = ((_right ? 1 : 0) - (_left ? 1 : 0)).toDouble();
      player.blockHeld = _block;
    } else {
      player.moveInput = 0;
      player.blockHeld = false;
    }
    _brain.enabled = rockAttacks.value && !_transitioning && !_resultPending;
    _brain.update(
      dtMs,
      arena.rock,
      player,
      rockPhaseStats[arena.step - 1],
      arena.step,
      arena.worldWidth,
    );

    arena.update(dtMs);
    _processEvents();
    combo.value = arena.combo;
    charge.value = arena.player.chargeFraction;
    _processSoundEdges();
    _checkProgress();

    playerHp.value = player.hpFraction;
    rockHp.value = arena.rock.hpFraction;
    knifeReady.value = 1 - (player.knifeCooldownMs / PlayerStats.knifeCooldownMs).clamp(0.0, 1.0);
  }

  void _processEvents() {
    for (final e in arena.events) {
      final at = Offset(e.x * _unit, _groundY + e.y * _unit);
      final blocked = e.kind == HitKind.blocked;
      final feel = hitFeelFor(e);
      add(HitSpark(pos: at, radius: feel.sparkRadius * _unit, blocked: blocked));
      if (feel.dust) {
        final dir = e.byPlayer ? (arena.rock.x >= arena.player.x ? 1 : -1) : (arena.player.x >= arena.rock.x ? 1 : -1);
        add(DustPuff(pos: Offset(at.dx, _groundY), scale: _unit, dir: dir));
      }
      _hitStopMs = math.max(_hitStopMs, feel.hitStopMs);
      _shake = math.max(_shake, feel.shake);
      if (feel.slowMs > 0 && _slowMoMs <= 0 && !_resultPending) {
        _slowScale = feel.slowScale;
        _slowMoMs = feel.slowMs;
      }
      _cheer = math.min(1, _cheer + (blocked ? 0.05 : (e.byPlayer ? 0.3 : 0.1)));

      // suara
      final audio = AudioService.instance;
      audio.play(feel.sfx);
      if (!e.byPlayer && !blocked) {
        audio.play(Sfx.hurt);
        hurtFlash.value++;
      }

      // getar: ringan saat memukul, sedang saat terkena, berat untuk Hantaman
      if (!blocked) {
        if (e.id == 'heavy') {
          HapticFeedback.heavyImpact();
        } else if (e.byPlayer) {
          HapticFeedback.lightImpact();
        } else {
          HapticFeedback.mediumImpact();
        }
      }
    }
    arena.events.clear();
  }

  /// Suara yang dipicu perubahan keadaan: pisau dilempar dan aba-aba serangan khusus Rock.
  void _processSoundEdges() {
    final knives = arena.knives.length;
    if (knives > _knivesWas) AudioService.instance.play(Sfx.whoosh);
    _knivesWas = knives;

    final full = arena.player.charging && arena.player.chargeFraction >= 1;
    if (full && !_chargeFullWas) AudioService.instance.play(Sfx.bell);
    _chargeFullWas = full;

    final telegraph = arena.rock.telegraphing;
    if (telegraph && !_telegraphWas) AudioService.instance.play(Sfx.warning);
    _telegraphWas = telegraph;
  }

  @override
  void render(Canvas canvas) {
    if (_shake > 0.5) {
      canvas.save();
      canvas.translate((_rnd.nextDouble() - 0.5) * _shake * 2, (_rnd.nextDouble() - 0.5) * _shake * 2);
      super.render(canvas);
      canvas.restore();
    } else {
      super.render(canvas);
    }
  }

  // ---------------- panel uji (sementara) ----------------
  void devPlay({required bool forPlayer, required String clipName}) {
    final clip = Clips.all[clipName];
    if (clip == null || !_ready) return;
    (forPlayer ? arena.player : arena.rock).playScripted(
      clip,
      holdMs: clip.holdLast || clip.loop ? 1500 : null,
    );
  }

  /// Memaksa menyelesaikan fase sekarang (laporan ke core, seperti saat Rock mencapai batas HP).
  void devWinPhase() {
    if (!_ready || !session.isPlaying || _resultPending) return;
    if (arena.step < 3) {
      arena.rock.hp = arena.rock.hpFloor;
      _checkProgress();
    } else {
      arena.rock.hp = 0;
      arena.rock.receiveHit(Attacks.kick.withDamage(1), arena.player.x);
    }
  }

  void devLose() {
    if (!_ready || !session.isPlaying || _resultPending) return;
    arena.player.receiveHit(Attacks.kick.withDamage(10000), arena.rock.x);
  }
}
